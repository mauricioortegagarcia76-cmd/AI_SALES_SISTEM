# AI Sales System V3.1

## Incluido
- Express + SQLite persistente.
- Registro/login con bcrypt + JWT.
- Datos aislados por usuario.
- OpenAI Responses API con JSON Schema.
- Límite mensual de IA.
- Shopify GraphQL Admin API desde backend.
- Webhook HMAC con deduplicación básica.
- Health check.
- GitHub Actions CI.
- Secretos y SQLite excluidos de Git.

## Local
```bash
npm install
cp .env.example .env
npm run check
npm start
```
Abrir `http://localhost:3000`.

## Producción
Para multiinstancia, migrar SQLite a PostgreSQL/Supabase. Configurar HTTPS, un `JWT_SECRET` aleatorio de alta entropía, CORS restringido al dominio real y backups.

## Shopify
Una tienda propia usa `SHOPIFY_SHOP_DOMAIN`, `SHOPIFY_ACCESS_TOKEN` y `SHOPIFY_API_SECRET`. Para vender el sistema como app a múltiples tiendas falta implementar instalación/token exchange y almacenamiento por tienda.
