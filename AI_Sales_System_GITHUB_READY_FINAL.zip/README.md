# AI Sales System V3.1

CRM + base de conocimiento + asistente de ventas con OpenAI + autenticación + persistencia + integración preparada para Shopify.

## Lo que ya está funcionando en esta entrega

- Backend Express.
- Registro e inicio de sesión.
- Contraseñas con bcrypt.
- JWT de sesión.
- Datos separados por usuario.
- Clientes y productos persistentes en SQLite.
- Asistente con OpenAI Responses API y salida JSON estructurada.
- Límite mensual de llamadas de IA.
- Health check.
- Shopify GraphQL Admin API desde el servidor.
- Verificación HMAC de webhooks Shopify y deduplicación por webhook ID.
- GitHub Actions para comprobaciones de sintaxis.
- `.env` y base SQLite excluidos del repositorio.

## Instalar

Requiere Node.js 18+.

```bash
npm install
cp .env.example .env
npm run check
npm start
```

Abre `http://localhost:3000`.

## OpenAI

Configura `OPENAI_API_KEY`. El valor por defecto es `gpt-5.6-luna`, configurable con `OPENAI_MODEL`.

## Shopify

Para una tienda propia configura:

```env
SHOPIFY_SHOP_DOMAIN=tu-tienda.myshopify.com
SHOPIFY_ACCESS_TOKEN=shpat_...
SHOPIFY_API_SECRET=...
SHOPIFY_API_VERSION=2026-07
```

La API key/token nunca se envía al navegador. El webhook recibe `POST /webhooks/shopify` y valida la firma HMAC.

## GitHub

1. Crea un repositorio nuevo en tu cuenta.
2. Sube el contenido de esta carpeta, no el `.env` ni `sales.db`.
3. GitHub Actions ejecutará `npm install` y `npm run check` en cada push/PR.

Si el repositorio se crea con GitHub CLI:

```bash
git init
git add .
git commit -m "feat: AI Sales System v3.1"
git branch -M main
git remote add origin <TU_REPOSITORIO>
git push -u origin main
```

## Importante antes de venderlo como app Shopify

Esta versión está preparada para una tienda propia mediante token de servidor. Para una app pública multi-tienda todavía hay que implementar el flujo oficial de instalación/token exchange de Shopify, guardar conexiones por tienda y completar las suscripciones de webhooks necesarias.
