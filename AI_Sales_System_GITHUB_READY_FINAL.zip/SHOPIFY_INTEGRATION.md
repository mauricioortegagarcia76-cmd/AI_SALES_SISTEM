# Shopify integration — V3

La base usa Shopify GraphQL Admin API desde el backend y verifica webhooks con HMAC. Shopify indica que las apps nuevas deben usar GraphQL Admin API y recomienda webhooks para sincronización de producción.

## Desarrollo con una tienda propia

Configura en `.env`:
- `SHOPIFY_SHOP_DOMAIN=tu-tienda.myshopify.com`
- `SHOPIFY_ACCESS_TOKEN=shpat_...`
- `SHOPIFY_API_SECRET=...`
- `SHOPIFY_API_VERSION=2026-07`

`GET /api/shopify/status` comprueba la configuración y `GET /api/shopify/products` prueba una consulta GraphQL de productos.

## Webhooks

Endpoint: `POST /webhooks/shopify`.

El servidor valida `X-Shopify-Hmac-Sha256`, registra `X-Shopify-Webhook-Id` para evitar duplicados y guarda el evento para sincronización posterior.

Para producción: `orders/create`, `products/update` y `app/uninstalled`, según las funciones que habilites.

## App pública multi-tienda

Esta entrega deja lista la capa GraphQL + webhooks, pero no simula un OAuth terminado. Para convertirla en una app pública hay que añadir el flujo de instalación/token exchange de Shopify CLI, guardar la conexión por tienda y usar tokens offline/expirables. El token debe permanecer en el backend.

## Seguridad

Nunca subas `.env`, `sales.db`, tokens de Shopify, secretos de Shopify ni `OPENAI_API_KEY` a GitHub.
