/* Authentication bridge for the V3 backend.
   The legacy UI can use this module gradually; the backend is already ready. */
window.AISalesAuth={
  get token(){return localStorage.getItem("ai_sales_token")||""},
  set token(v){localStorage.setItem("ai_sales_token",v)},
  clear(){localStorage.removeItem("ai_sales_token")},
  async request(url,options={}){
    const headers={...(options.headers||{}), "Content-Type":"application/json"};
    if(this.token) headers.Authorization=`Bearer ${this.token}`;
    const r=await fetch(url,{...options,headers});
    const data=await r.json().catch(()=>({}));
    if(!r.ok) throw new Error(data.error||"Solicitud fallida");
    return data;
  }
};