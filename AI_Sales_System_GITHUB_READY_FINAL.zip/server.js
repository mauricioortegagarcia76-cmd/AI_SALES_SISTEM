require('dotenv').config();
const express=require('express');
const path=require('path');
const crypto=require('crypto');
const bcrypt=require('bcryptjs');
const jwt=require('jsonwebtoken');
const Database=require('better-sqlite3');
const helmet=require('helmet');
const cors=require('cors');
const OpenAI=require('openai');

const app=express();
const PORT=Number(process.env.PORT||3000);
const JWT_SECRET=process.env.JWT_SECRET;
const AI_LIMIT=Number(process.env.AI_MONTHLY_LIMIT||100);
const SHOPIFY_API_VERSION=process.env.SHOPIFY_API_VERSION||'2026-07';
const SHOPIFY_SHOP_DOMAIN=String(process.env.SHOPIFY_SHOP_DOMAIN||'').replace(/^https?:\/\//,'').replace(/\/$/,'');
const SHOPIFY_ACCESS_TOKEN=process.env.SHOPIFY_ACCESS_TOKEN||'';
const SHOPIFY_API_SECRET=process.env.SHOPIFY_API_SECRET||'';

if(process.env.NODE_ENV==='production' && (!JWT_SECRET || JWT_SECRET.length<32)){
  throw new Error('JWT_SECRET debe existir y tener al menos 32 caracteres en producción');
}
const db=new Database(path.join(__dirname,'sales.db'));
db.pragma('journal_mode = WAL');

db.exec(`
CREATE TABLE IF NOT EXISTS users(
 id TEXT PRIMARY KEY, email TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL,
 business_name TEXT NOT NULL DEFAULT 'Mi negocio', tone TEXT NOT NULL DEFAULT 'Natural, profesional y breve',
 rules TEXT NOT NULL DEFAULT 'No inventar precios, stock, descuentos, beneficios, testimonios, garantías, pagos, envíos ni políticas.',
 created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS customers(
 id TEXT PRIMARY KEY, user_id TEXT NOT NULL, name TEXT, contact TEXT, status TEXT, intent TEXT,
 product TEXT, need TEXT, objection TEXT, next_action TEXT, next_action_at TEXT, notes TEXT,
 history_json TEXT NOT NULL DEFAULT '[]', created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS products(
 id TEXT PRIMARY KEY, user_id TEXT NOT NULL, name TEXT, sku TEXT, price REAL DEFAULT 0,
 stock TEXT, benefits_json TEXT NOT NULL DEFAULT '[]', features_json TEXT NOT NULL DEFAULT '[]',
 payment TEXT, delivery TEXT, guarantee TEXT, approved_discount TEXT,
 created_at TEXT NOT NULL, updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS usage(user_id TEXT NOT NULL, month TEXT NOT NULL, ai_calls INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(user_id,month));
CREATE TABLE IF NOT EXISTS shopify_events(id TEXT PRIMARY KEY, topic TEXT, shop_domain TEXT, payload_json TEXT, received_at TEXT NOT NULL);
`);

app.disable('x-powered-by');
app.use(helmet({contentSecurityPolicy:false}));
app.use(cors({origin:process.env.CORS_ORIGIN||true,credentials:true}));

// Shopify webhooks must be verified against the raw request body.
app.post('/webhooks/shopify',express.raw({type:'application/json',limit:'2mb'}),async(req,res)=>{
  try{
    if(!SHOPIFY_API_SECRET) return res.status(503).send('Shopify webhook secret not configured');
    const hmac=req.get('X-Shopify-Hmac-Sha256')||'';
    const digest=crypto.createHmac('sha256',SHOPIFY_API_SECRET).update(req.body).digest('base64');
    const valid=hmac && crypto.timingSafeEqual(Buffer.from(hmac),Buffer.from(digest));
    if(!valid) return res.status(401).send('Invalid webhook signature');
    const topic=req.get('X-Shopify-Topic')||'unknown';
    const shop=req.get('X-Shopify-Shop-Domain')||'';
    const eventId=req.get('X-Shopify-Webhook-Id')||crypto.randomUUID();
    const exists=db.prepare('SELECT id FROM shopify_events WHERE id=?').get(eventId);
    if(!exists) db.prepare('INSERT INTO shopify_events(id,topic,shop_domain,payload_json,received_at) VALUES(?,?,?,?,?)').run(eventId,topic,shop,req.body.toString('utf8'),new Date().toISOString());
    res.status(200).send('ok');
  }catch(e){console.error('Shopify webhook error:',e.message);res.status(500).send('Webhook error');}
});

app.use(express.json({limit:'1mb'}));
app.use(express.static(__dirname));

const ai=process.env.OPENAI_API_KEY?new OpenAI({apiKey:process.env.OPENAI_API_KEY}):null;
const now=()=>new Date().toISOString();
const id=()=>crypto.randomUUID();
const month=()=>new Date().toISOString().slice(0,7);
function tokenFor(user){return jwt.sign({sub:user.id,email:user.email},JWT_SECRET,{expiresIn:'7d'});}
function auth(req,res,next){const h=req.headers.authorization||'';if(!h.startsWith('Bearer '))return res.status(401).json({error:'No autenticado'});try{req.user=jwt.verify(h.slice(7),JWT_SECRET);next();}catch{return res.status(401).json({error:'Sesión inválida o expirada'});}}
function userRow(uid){return db.prepare('SELECT * FROM users WHERE id=?').get(uid);}
function publicUser(u){return {id:u.id,email:u.email,businessName:u.business_name,tone:u.tone,rules:u.rules};}
function jsonArray(v){try{return JSON.parse(v||'[]')}catch{return []}}

app.get('/api/health',(_req,res)=>res.json({ok:true,aiConfigured:Boolean(ai),shopifyConfigured:Boolean(SHOPIFY_SHOP_DOMAIN&&SHOPIFY_ACCESS_TOKEN),version:'3.1.0'}));

app.post('/api/auth/register',async(req,res)=>{const email=String(req.body.email||'').trim().toLowerCase(),password=String(req.body.password||''),businessName=String(req.body.businessName||'Mi negocio').trim()||'Mi negocio';if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))return res.status(400).json({error:'Correo inválido'});if(password.length<8)return res.status(400).json({error:'La contraseña debe tener al menos 8 caracteres'});if(db.prepare('SELECT id FROM users WHERE email=?').get(email))return res.status(409).json({error:'Ese correo ya está registrado'});const u={id:id(),email,password_hash:await bcrypt.hash(password,12),business_name:businessName,created_at:now()};db.prepare('INSERT INTO users(id,email,password_hash,business_name,created_at) VALUES(?,?,?,?,?)').run(u.id,u.email,u.password_hash,u.business_name,u.created_at);const full={...u,tone:'Natural, profesional y breve',rules:'No inventar precios, stock, descuentos, beneficios, testimonios, garantías, pagos, envíos ni políticas.'};res.status(201).json({token:tokenFor(full),user:publicUser(full)});});
app.post('/api/auth/login',async(req,res)=>{const email=String(req.body.email||'').trim().toLowerCase(),password=String(req.body.password||'');const u=db.prepare('SELECT * FROM users WHERE email=?').get(email);if(!u||!(await bcrypt.compare(password,u.password_hash)))return res.status(401).json({error:'Correo o contraseña incorrectos'});res.json({token:tokenFor(u),user:publicUser(u)});});
app.get('/api/me',auth,(req,res)=>{const u=userRow(req.user.sub);if(!u)return res.status(401).json({error:'Usuario no encontrado'});res.json({user:publicUser(u)});});
app.put('/api/settings',auth,(req,res)=>{const u=userRow(req.user.sub);const businessName=String(req.body.businessName??u.business_name).trim()||u.business_name,tone=String(req.body.tone??u.tone),rules=String(req.body.rules??u.rules);db.prepare('UPDATE users SET business_name=?,tone=?,rules=? WHERE id=?').run(businessName,tone,rules,u.id);res.json({user:publicUser(userRow(u.id))});});

app.get('/api/customers',auth,(req,res)=>res.json(db.prepare('SELECT * FROM customers WHERE user_id=? ORDER BY updated_at DESC').all(req.user.sub).map(x=>({...x,history:jsonArray(x.history_json)}))));
app.post('/api/customers',auth,(req,res)=>{const x=req.body,c={id:id(),user_id:req.user.sub,name:String(x.name||''),contact:String(x.contact||''),status:x.status||'Nuevo',intent:x.intent||'Baja',product:String(x.product||''),need:String(x.need||''),objection:String(x.objection||''),next_action:String(x.nextAction||''),next_action_at:String(x.nextActionAt||''),notes:String(x.notes||''),history_json:JSON.stringify([{date:now(),type:'note',text:'Cliente creado'}]),created_at:now(),updated_at:now()};db.prepare(`INSERT INTO customers(id,user_id,name,contact,status,intent,product,need,objection,next_action,next_action_at,notes,history_json,created_at,updated_at) VALUES(@id,@user_id,@name,@contact,@status,@intent,@product,@need,@objection,@next_action,@next_action_at,@notes,@history_json,@created_at,@updated_at)`).run(c);res.status(201).json({...c,history:jsonArray(c.history_json)});});
app.put('/api/customers/:id',auth,(req,res)=>{const old=db.prepare('SELECT * FROM customers WHERE id=? AND user_id=?').get(req.params.id,req.user.sub);if(!old)return res.status(404).json({error:'Cliente no encontrado'});const x=req.body,fields={name:x.name??old.name,contact:x.contact??old.contact,status:x.status??old.status,intent:x.intent??old.intent,product:x.product??old.product,need:x.need??old.need,objection:x.objection??old.objection,next_action:x.nextAction??old.next_action,next_action_at:x.nextActionAt??old.next_action_at,notes:x.notes??old.notes,updated_at:now()};db.prepare(`UPDATE customers SET name=@name,contact=@contact,status=@status,intent=@intent,product=@product,need=@need,objection=@objection,next_action=@next_action,next_action_at=@next_action_at,notes=@notes,updated_at=@updated_at WHERE id=@id AND user_id=@uid`).run({...fields,id:old.id,uid:req.user.sub});res.json(db.prepare('SELECT * FROM customers WHERE id=? AND user_id=?').get(old.id,req.user.sub));});
app.delete('/api/customers/:id',auth,(req,res)=>{db.prepare('DELETE FROM customers WHERE id=? AND user_id=?').run(req.params.id,req.user.sub);res.json({ok:true});});

app.get('/api/products',auth,(req,res)=>res.json(db.prepare('SELECT * FROM products WHERE user_id=? ORDER BY updated_at DESC').all(req.user.sub).map(x=>({...x,approvedBenefits:jsonArray(x.benefits_json),features:jsonArray(x.features_json)}))));
app.post('/api/products',auth,(req,res)=>{const x=req.body,p={id:id(),user_id:req.user.sub,name:String(x.name||''),sku:String(x.sku||''),price:Number(x.price||0),stock:x.stock||'No especificado',benefits_json:JSON.stringify(x.approvedBenefits||[]),features_json:JSON.stringify(x.features||[]),payment:String(x.payment||''),delivery:String(x.delivery||''),guarantee:String(x.guarantee||''),approved_discount:String(x.approvedDiscount||''),created_at:now(),updated_at:now()};db.prepare(`INSERT INTO products(id,user_id,name,sku,price,stock,benefits_json,features_json,payment,delivery,guarantee,approved_discount,created_at,updated_at) VALUES(@id,@user_id,@name,@sku,@price,@stock,@benefits_json,@features_json,@payment,@delivery,@guarantee,@approved_discount,@created_at,@updated_at)`).run(p);res.status(201).json({...p,approvedBenefits:jsonArray(p.benefits_json),features:jsonArray(p.features_json)});});
app.put('/api/products/:id',auth,(req,res)=>{const old=db.prepare('SELECT * FROM products WHERE id=? AND user_id=?').get(req.params.id,req.user.sub);if(!old)return res.status(404).json({error:'Producto no encontrado'});const x=req.body,p={name:x.name??old.name,sku:x.sku??old.sku,price:Number(x.price??old.price),stock:x.stock??old.stock,benefits_json:JSON.stringify(x.approvedBenefits??jsonArray(old.benefits_json)),features_json:JSON.stringify(x.features??jsonArray(old.features_json)),payment:x.payment??old.payment,delivery:x.delivery??old.delivery,guarantee:x.guarantee??old.guarantee,approved_discount:x.approvedDiscount??old.approved_discount,updated_at:now()};db.prepare(`UPDATE products SET name=@name,sku=@sku,price=@price,stock=@stock,benefits_json=@benefits_json,features_json=@features_json,payment=@payment,delivery=@delivery,guarantee=@guarantee,approved_discount=@approved_discount,updated_at=@updated_at WHERE id=@id AND user_id=@uid`).run({...p,id:old.id,uid:req.user.sub});res.json(db.prepare('SELECT * FROM products WHERE id=? AND user_id=?').get(old.id,req.user.sub));});
app.delete('/api/products/:id',auth,(req,res)=>{db.prepare('DELETE FROM products WHERE id=? AND user_id=?').run(req.params.id,req.user.sub);res.json({ok:true});});

const SYS=`Eres el asistente de ventas de AI Sales System. Analiza el mensaje de un cliente y ayuda al vendedor. No inventes precios, stock, descuentos, beneficios, testimonios, garantías, pagos, envíos ni políticas. Usa solamente los datos entregados. Si falta información importante usa [PENDIENTE]. Si hay contradicción, pide confirmación. No inventes urgencia, escasez ni presión. No presentes beneficios médicos/psicológicos no documentados. Responde en español natural, profesional y breve. Devuelve exclusivamente JSON válido.`;
app.post('/api/ai/analyze',auth,async(req,res)=>{if(!ai)return res.status(503).json({error:'OPENAI_API_KEY no configurada'});const u=userRow(req.user.sub),m=month(),usage=db.prepare('SELECT ai_calls FROM usage WHERE user_id=? AND month=?').get(u.id,m);if((usage?.ai_calls||0)>=AI_LIMIT)return res.status(429).json({error:'Límite mensual de IA alcanzado'});const message=String(req.body.message||'').trim();if(!message)return res.status(400).json({error:'Falta el mensaje del cliente'});try{const r=await ai.responses.create({model:process.env.OPENAI_MODEL||'gpt-5.6-luna',instructions:SYS,input:JSON.stringify({negocio:{name:u.business_name,tone:u.tone,rules:u.rules},producto:req.body.product||null,mensaje_cliente:message}),text:{format:{type:'json_schema',name:'sales_analysis',strict:true,schema:{type:'object',additionalProperties:false,properties:{situacion:{type:'string'},estado:{type:'string'},intencion:{type:'string'},necesidad:{type:'string'},objecion:{type:'string'},respuesta:{type:'string'},siguiente_paso:{type:'string'},proxima_fecha:{type:'string'},informacion_pendiente:{type:'array',items:{type:'string'}}},required:['situacion','estado','intencion','necesidad','objecion','respuesta','siguiente_paso','proxima_fecha','informacion_pendiente']}}}});db.prepare(`INSERT INTO usage(user_id,month,ai_calls) VALUES(?,?,1) ON CONFLICT(user_id,month) DO UPDATE SET ai_calls=ai_calls+1`).run(u.id,m);res.json(JSON.parse(r.output_text));}catch(e){console.error('AI error:',e.message);res.status(502).json({error:'Error al consultar la IA'});}});

async function shopifyGraphQL(query,variables={}){if(!SHOPIFY_SHOP_DOMAIN||!SHOPIFY_ACCESS_TOKEN)throw new Error('Shopify no configurado');const r=await fetch(`https://${SHOPIFY_SHOP_DOMAIN}/admin/api/${SHOPIFY_API_VERSION}/graphql.json`,{method:'POST',headers:{'Content-Type':'application/json','X-Shopify-Access-Token':SHOPIFY_ACCESS_TOKEN},body:JSON.stringify({query,variables})});const data=await r.json();if(!r.ok||data.errors)throw new Error(data.errors?.map(x=>x.message).join('; ')||`Shopify HTTP ${r.status}`);return data;}
app.get('/api/shopify/status',auth,(_req,res)=>res.json({configured:Boolean(SHOPIFY_SHOP_DOMAIN&&SHOPIFY_ACCESS_TOKEN),shopDomain:SHOPIFY_SHOP_DOMAIN||null,apiVersion:SHOPIFY_API_VERSION}));
app.get('/api/shopify/products',auth,async(_req,res)=>{try{const data=await shopifyGraphQL(`query { products(first: 20) { nodes { id title handle status totalInventory variants(first: 20) { nodes { id sku price inventoryQuantity } } } } }`);res.json(data.data.products.nodes);}catch(e){res.status(502).json({error:e.message});}});

app.use((err,_req,res,_next)=>{console.error(err);res.status(500).json({error:'Error interno del servidor'});});
app.use((req,res,next)=>{ if(req.path.startsWith('/api/')||req.path.startsWith('/webhooks/')) return res.status(404).json({error:'Ruta no encontrada'}); res.sendFile(path.join(__dirname,'index.html')); });
app.listen(PORT,()=>console.log(`AI Sales System listening on ${PORT}`));
